package com.example.vales_imapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class GalleryScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);
    }
}