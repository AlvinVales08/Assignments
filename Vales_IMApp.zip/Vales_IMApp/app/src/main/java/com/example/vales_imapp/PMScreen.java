package com.example.vales_imapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PMScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p_m_screen);
    }
}